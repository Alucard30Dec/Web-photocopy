namespace WebPhotocopyHub.Web.Models;

public class ShopDirectoryViewModel
{
    public IReadOnlyList<ShopBranchLinkViewModel> Branches { get; set; } = Array.Empty<ShopBranchLinkViewModel>();
}

public class ShopBranchLinkViewModel
{
    public string Slug { get; set; } = string.Empty;

    public string Name { get; set; } = string.Empty;

    public string Address { get; set; } = string.Empty;

    public string ShortDescription { get; set; } = string.Empty;

    public string PhoneNumber { get; set; } = string.Empty;

    public string OpenHours { get; set; } = string.Empty;

    public string CustomerNote { get; set; } = string.Empty;

    public IReadOnlyList<string> PopularServices { get; set; } = Array.Empty<string>();

    public IReadOnlyList<string> QuickOptions { get; set; } = Array.Empty<string>();
}