using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.Extensions.DependencyInjection;
using PhotoCopyHub.Web.Admin;
using PhotoCopyHub.Web.Control;
using PhotoCopyHub.Web.Customer;
using PhotoCopyHub.Web.Admin_Shop;
using PhotoCopyHub.Web.Sys;

namespace PhotoCopyHub.Web;

public static class WebModuleRegistration
{
    public static IMvcBuilder AddPhotoCopyHubWebModules(this IMvcBuilder p_objBuilder)
    {
        Add_Module(p_objBuilder, typeof(WebControlModuleMarker));
        Add_Module(p_objBuilder, typeof(WebCustomerModuleMarker));
        Add_Module(p_objBuilder, typeof(WebAdminShopModuleMarker));
        Add_Module(p_objBuilder, typeof(WebAdminModuleMarker));
        Add_Module(p_objBuilder, typeof(WebSysModuleMarker));

        return p_objBuilder;
    }

    private static void Add_Module(IMvcBuilder p_objBuilder, Type p_objMarkerType)
    {
        var v_asmModule = p_objMarkerType.Assembly;
        if (p_objBuilder.PartManager.ApplicationParts
            .OfType<AssemblyPart>()
            .Any(p_objPart => p_objPart.Assembly == v_asmModule))
        {
            return;
        }

        p_objBuilder.AddApplicationPart(v_asmModule);
    }
}
