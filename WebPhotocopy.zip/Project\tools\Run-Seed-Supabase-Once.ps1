$ErrorActionPreference = "Stop"

$ProjectRoot = 'E:\OneDrive - 0dpmr\WebPhotocopy\Project'
if (-not (Test-Path -LiteralPath $ProjectRoot)) {
    throw "Không tìm thấy thư mục dự án: $ProjectRoot"
}

Set-Location -LiteralPath $ProjectRoot

$WebProjectPath = Join-Path $ProjectRoot 'WebPhotocopyHub_Web\WebPhotocopyHub_Web.csproj'
if (-not (Test-Path -LiteralPath $WebProjectPath)) {
    throw "Không tìm thấy web project: $WebProjectPath"
}

Write-Host ""
Write-Host "Dán Supabase Session Pooler URI dạng:" -ForegroundColor Cyan
Write-Host "postgres://postgres.<project-ref>:<password>@aws-<region>.pooler.supabase.com:5432/postgres" -ForegroundColor Yellow
Write-Host "Không dùng [YOUR-PASSWORD]. Nếu password có ký tự đặc biệt, hãy URL-encode password trước khi dán." -ForegroundColor Yellow
Write-Host ""

$Connection = Read-Host "Supabase PostgreSQL connection string"

if ([string]::IsNullOrWhiteSpace($Connection)) {
    throw "Connection string đang rỗng."
}

if ($Connection -like '*[YOUR-PASSWORD]*') {
    throw "Connection string vẫn còn [YOUR-PASSWORD]. Hãy thay bằng password thật."
}

$env:ASPNETCORE_ENVIRONMENT = "Development"
$env:BrowserLaunch__Enabled = "false"
$env:Swagger__Enabled = "false"
$env:SeedSampleData__Enabled = "true"
$env:PHOTOCOPYHUB_SEED_ONLY = "true"
$env:PHOTOCOPYHUB_POSTGRES_CONNECTION = $Connection

Write-Host ""
Write-Host "Đang seed 1 lần vào Supabase/PostgreSQL. App sẽ tự thoát sau khi seed xong..." -ForegroundColor Cyan
dotnet run --project $WebProjectPath --no-launch-profile

if ($LASTEXITCODE -ne 0) {
    throw "Seed thất bại. Hãy gửi lại toàn bộ log từ dòng lỗi đầu tiên."
}

Write-Host ""
Write-Host "Seed 1 lần hoàn tất. Hãy kiểm tra Supabase Table Editor và đăng nhập bằng tài khoản mẫu." -ForegroundColor Green