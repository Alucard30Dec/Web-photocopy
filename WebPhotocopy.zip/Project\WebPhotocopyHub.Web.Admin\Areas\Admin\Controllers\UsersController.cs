using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.RateLimiting;
using WebPhotocopyHub.Application.Common;
using WebPhotocopyHub.Application.Contracts;
using WebPhotocopyHub.Application.DTOs;
using WebPhotocopyHub.Domain.Constants;
using WebPhotocopyHub.Domain.Entities;
using WebPhotocopyHub.Domain.Enums;
using WebPhotocopyHub.Web.Extensions;
using WebPhotocopyHub.Web.Admin.Models;

namespace WebPhotocopyHub.Web.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize(Roles = RoleConstants.Admin)]
public class UsersController : Controller
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly RoleManager<IdentityRole> _roleManager;
    private readonly IWalletService _walletService;
    private readonly IAuditLogService _auditLogService;
    private readonly IAdminUserQueryService _adminUserQueryService;

    public UsersController(
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager,
        IWalletService walletService,
        IAuditLogService auditLogService,
        IAdminUserQueryService adminUserQueryService)
    {
        _userManager = userManager;
        _roleManager = roleManager;
        _walletService = walletService;
        _auditLogService = auditLogService;
        _adminUserQueryService = adminUserQueryService;
    }

    [HttpGet]
    public async Task<IActionResult> Index(CancellationToken cancellationToken)
    {
        var users = await _adminUserQueryService.ListUsersAsync(cancellationToken);
        var roleMap = await _adminUserQueryService.GetPrimaryRoleMapAsync(users, cancellationToken);

        ViewBag.RoleMap = roleMap;
        ViewBag.AvailableRoles = new[] { RoleConstants.Customer, RoleConstants.ShopOperator, RoleConstants.Admin };
        return View(users);
    }

    [HttpGet]
    public async Task<IActionResult> AdjustBalance(string userId)
    {
        var user = await _userManager.FindByIdAsync(userId);
        if (user is null)
        {
            return NotFound();
        }

        ViewBag.TargetUser = user;
        return View(new ManualAdjustBalanceViewModel { UserId = userId });
    }

    [HttpPost]
    [EnableRateLimiting("money")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AdjustBalance(ManualAdjustBalanceViewModel model, CancellationToken cancellationToken)
    {
        var user = await _userManager.FindByIdAsync(model.UserId);
        if (user is null)
        {
            return NotFound();
        }

        ViewBag.TargetUser = user;

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        try
        {
            await _walletService.ManualAdjustAsync(new WalletOperationRequestDto
            {
                UserId = model.UserId,
                Amount = model.Amount,
                TransactionType = WalletTransactionType.ManualAdjustment,
                Note = model.Note,
                IdempotencyKey = model.IdempotencyKey,
                PerformedByAdminId = User.GetUserId()
            }, cancellationToken);

            await _auditLogService.WriteAsync(new AuditLogEntryDto
            {
                ActorUserId = User.GetUserId(),
                Action = "ManualAdjustBalance",
                EntityName = nameof(ApplicationUser),
                EntityId = model.UserId,
                Details = $"Amount: {model.Amount}; Note: {model.Note}",
                IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString()
            }, cancellationToken);

            TempData["Success"] = "Điều chỉnh số dư thành công.";
            return RedirectToAction(nameof(Index));
        }
        catch (BusinessException ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
            return View(model);
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ToggleActive(string userId, CancellationToken cancellationToken)
    {
        var user = await _userManager.FindByIdAsync(userId);
        if (user is null)
        {
            return NotFound();
        }

        if (string.Equals(User.GetUserId(), userId, StringComparison.Ordinal))
        {
            TempData["Error"] = "Không thể tự khóa tài khoản của chính bạn.";
            return RedirectToAction(nameof(Index));
        }

        user.IsActive = !user.IsActive;
        await _userManager.UpdateAsync(user);

        await _auditLogService.WriteAsync(new AuditLogEntryDto
        {
            ActorUserId = User.GetUserId(),
            Action = "ToggleUserActive",
            EntityName = nameof(ApplicationUser),
            EntityId = user.Id,
            Details = $"IsActive: {user.IsActive}",
            IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString()
        }, cancellationToken);

        TempData["Success"] = user.IsActive ? "Đã mở khóa tài khoản." : "Đã khóa tài khoản.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SetRole(string userId, string roleName, CancellationToken cancellationToken)
    {
        if (!new[] { RoleConstants.Customer, RoleConstants.ShopOperator, RoleConstants.Admin }.Contains(roleName))
        {
            TempData["Error"] = "Role không hợp lệ.";
            return RedirectToAction(nameof(Index));
        }

        var user = await _userManager.FindByIdAsync(userId);
        if (user is null)
        {
            return NotFound();
        }

        if (!await _roleManager.RoleExistsAsync(roleName))
        {
            TempData["Error"] = "Role chưa tồn tại trong hệ thống.";
            return RedirectToAction(nameof(Index));
        }

        var currentRoles = await _userManager.GetRolesAsync(user);
        var removableRoles = currentRoles.Where(x =>
            x == RoleConstants.Customer ||
            x == RoleConstants.ShopOperator ||
            x == RoleConstants.Admin).ToList();

        if (removableRoles.Any())
        {
            await _userManager.RemoveFromRolesAsync(user, removableRoles);
        }

        await _userManager.AddToRoleAsync(user, roleName);

        await _auditLogService.WriteAsync(new AuditLogEntryDto
        {
            ActorUserId = User.GetUserId(),
            Action = "SetUserRole",
            EntityName = nameof(ApplicationUser),
            EntityId = user.Id,
            Details = $"Role: {roleName}",
            IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString()
        }, cancellationToken);

        TempData["Success"] = "Cập nhật role người dùng thành công.";
        return RedirectToAction(nameof(Index));
    }
}
