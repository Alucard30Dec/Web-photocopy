using System.ComponentModel;
using System.Diagnostics;
using Microsoft.AspNetCore.Http;

namespace WebPhotocopyHub.Web.Customer.Services;

internal static class OfficePreviewConverter
{
    private const int ConversionTimeoutSeconds = 60;
    private const long MaxPreviewPdfSizeBytes = 60L * 1024 * 1024;

    private static readonly HashSet<string> SupportedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx"
    };

    public static bool IsSupportedExtension(string extension)
    {
        return SupportedExtensions.Contains(extension);
    }

    public static async Task<OfficePreviewResult> ConvertToPdfAsync(
        IFormFile file,
        CancellationToken cancellationToken)
    {
        var safeFileName = Path.GetFileName(file.FileName);
        var extension = Path.GetExtension(safeFileName).ToLowerInvariant();

        if (!IsSupportedExtension(extension))
        {
            throw new InvalidDataException("Định dạng Office này chưa được hỗ trợ xem trước.");
        }

        var libreOfficePath = ResolveLibreOfficePath();
        if (string.IsNullOrWhiteSpace(libreOfficePath))
        {
            throw new OfficePreviewUnavailableException(
                "Máy chủ chưa cài LibreOffice. Hãy cài LibreOffice hoặc lưu tài liệu thành PDF để xem trước.");
        }

        var workRoot = Path.Combine(
            Path.GetTempPath(),
            "WebPhotocopyHub",
            "OfficePreview",
            Guid.NewGuid().ToString("N"));
        var outputDirectory = Path.Combine(workRoot, "output");
        var profileDirectory = Path.Combine(workRoot, "profile");
        var inputPath = Path.Combine(workRoot, "source" + extension);
        var expectedPdfPath = Path.Combine(outputDirectory, "source.pdf");

        Directory.CreateDirectory(outputDirectory);
        Directory.CreateDirectory(profileDirectory);

        try
        {
            await using (var destination = new FileStream(
                inputPath,
                FileMode.CreateNew,
                FileAccess.Write,
                FileShare.None,
                81920,
                FileOptions.Asynchronous | FileOptions.SequentialScan))
            {
                await file.CopyToAsync(destination, cancellationToken);
            }

            var startInfo = new ProcessStartInfo
            {
                FileName = libreOfficePath,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                WorkingDirectory = workRoot
            };

            var profileUri = new Uri(
                profileDirectory.TrimEnd(Path.DirectorySeparatorChar) +
                Path.DirectorySeparatorChar).AbsoluteUri;

            startInfo.ArgumentList.Add($"-env:UserInstallation={profileUri}");
            startInfo.ArgumentList.Add("--headless");
            startInfo.ArgumentList.Add("--nologo");
            startInfo.ArgumentList.Add("--nodefault");
            startInfo.ArgumentList.Add("--nolockcheck");
            startInfo.ArgumentList.Add("--norestore");
            startInfo.ArgumentList.Add("--convert-to");
            startInfo.ArgumentList.Add("pdf");
            startInfo.ArgumentList.Add("--outdir");
            startInfo.ArgumentList.Add(outputDirectory);
            startInfo.ArgumentList.Add(inputPath);

            using var process = new Process { StartInfo = startInfo };
            try
            {
                if (!process.Start())
                {
                    throw new OfficePreviewUnavailableException(
                        "Không thể khởi động LibreOffice để tạo bản xem trước.");
                }
            }
            catch (Win32Exception ex)
            {
                throw new OfficePreviewUnavailableException(
                    "Không thể khởi động LibreOffice để tạo bản xem trước.",
                    ex);
            }

            var standardOutputTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
            var standardErrorTask = process.StandardError.ReadToEndAsync(cancellationToken);

            using var timeoutSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeoutSource.CancelAfter(TimeSpan.FromSeconds(ConversionTimeoutSeconds));

            try
            {
                await process.WaitForExitAsync(timeoutSource.Token);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                TryKill(process);
                throw new TimeoutException("LibreOffice conversion timed out.");
            }

            var standardOutput = await standardOutputTask;
            var standardError = await standardErrorTask;

            if (process.ExitCode != 0 || !File.Exists(expectedPdfPath))
            {
                var diagnostic = FirstNonEmptyLine(standardError, standardOutput);
                throw new InvalidDataException(
                    string.IsNullOrWhiteSpace(diagnostic)
                        ? "Không thể chuyển file Office sang PDF. File có thể bị lỗi hoặc được bảo vệ bằng mật khẩu."
                        : $"Không thể chuyển file Office sang PDF: {diagnostic}");
            }

            var pdfInfo = new FileInfo(expectedPdfPath);
            if (pdfInfo.Length <= 4 || pdfInfo.Length > MaxPreviewPdfSizeBytes)
            {
                throw new InvalidDataException("Bản PDF xem trước không hợp lệ hoặc vượt quá giới hạn cho phép.");
            }

            var pdfBytes = await File.ReadAllBytesAsync(expectedPdfPath, cancellationToken);
            if (pdfBytes.Length < 4 ||
                pdfBytes[0] != (byte)'%' ||
                pdfBytes[1] != (byte)'P' ||
                pdfBytes[2] != (byte)'D' ||
                pdfBytes[3] != (byte)'F')
            {
                throw new InvalidDataException("LibreOffice không tạo được một file PDF hợp lệ.");
            }

            return new OfficePreviewResult(pdfBytes);
        }
        finally
        {
            TryDeleteDirectory(workRoot);
        }
    }

    private static string? ResolveLibreOfficePath()
    {
        var configuredPath =
            Environment.GetEnvironmentVariable("WEBPHOTOCOPYHUB_LIBREOFFICE_PATH") ??
            Environment.GetEnvironmentVariable("LIBREOFFICE_PATH");

        foreach (var candidate in BuildCandidates(configuredPath))
        {
            if (!string.IsNullOrWhiteSpace(candidate) && File.Exists(candidate))
            {
                return candidate;
            }
        }

        return null;
    }

    private static IEnumerable<string> BuildCandidates(string? configuredPath)
    {
        if (!string.IsNullOrWhiteSpace(configuredPath))
        {
            yield return configuredPath;

            if (Directory.Exists(configuredPath))
            {
                yield return Path.Combine(configuredPath, "soffice.exe");
                yield return Path.Combine(configuredPath, "program", "soffice.exe");
            }
        }

        var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        if (!string.IsNullOrWhiteSpace(programFiles))
        {
            yield return Path.Combine(programFiles, "LibreOffice", "program", "soffice.exe");
        }

        var programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
        if (!string.IsNullOrWhiteSpace(programFilesX86))
        {
            yield return Path.Combine(programFilesX86, "LibreOffice", "program", "soffice.exe");
        }

        yield return "/usr/bin/libreoffice";
        yield return "/usr/bin/soffice";

        var pathValue = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        foreach (var pathPart in pathValue.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            var normalizedPart = pathPart.Trim().Trim('"');
            if (string.IsNullOrWhiteSpace(normalizedPart))
            {
                continue;
            }

            yield return Path.Combine(normalizedPart, OperatingSystem.IsWindows() ? "soffice.exe" : "soffice");
            yield return Path.Combine(normalizedPart, OperatingSystem.IsWindows() ? "libreoffice.exe" : "libreoffice");
        }
    }

    private static string FirstNonEmptyLine(params string[] values)
    {
        foreach (var value in values)
        {
            var line = value
                .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim())
                .FirstOrDefault(x => !string.IsNullOrWhiteSpace(x));

            if (!string.IsNullOrWhiteSpace(line))
            {
                return line.Length <= 240 ? line : line[..240];
            }
        }

        return string.Empty;
    }

    private static void TryKill(Process process)
    {
        try
        {
            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
            }
        }
        catch
        {
            // Best-effort cleanup after timeout.
        }
    }

    private static void TryDeleteDirectory(string path)
    {
        try
        {
            if (Directory.Exists(path))
            {
                Directory.Delete(path, recursive: true);
            }
        }
        catch
        {
            // Temporary preview files are cleaned up best-effort.
        }
    }
}

internal sealed record OfficePreviewResult(byte[] PdfBytes);

internal sealed class OfficePreviewUnavailableException : Exception
{
    public OfficePreviewUnavailableException(string message)
        : base(message)
    {
    }

    public OfficePreviewUnavailableException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
